const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const instance = express();
instance.use(bodyParser.json());
instance.use(bodyParser.urlencoded({ extended: false }));
instance.use(cors());
const categories = [
    { CatId: 201, CatName: 'C1' },
    { CatId: 202, CatName: 'C2' }
];

instance.get('/api/categories', (req, resp) => {
    resp.json({ statusCode: 200, data: categories });
    resp.end();
});

instance.post('/api/categories', (req, resp) => {
    const category = {
        CatId: req.body.CatId,
        CatName: req.body.CatName
    };
    categories.push(category);
    resp.json({ statusCode: 200, data: categories });
    resp.end();
});



instance.listen('9089', () => {
    console.log('Server started on port 9089');
});