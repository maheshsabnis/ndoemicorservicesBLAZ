const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Sequelize, Model, DataTypes } = require('sequelize');
const instance = express();
instance.use(bodyParser.json());
instance.use(bodyParser.urlencoded({ extended: false }));
instance.use(cors());

const sequelize = new Sequelize("company", "user", "P@ssw0rd_", {
    host: "database",
    port: 33306,
    dialect: 'mysql',
    pool: {
        min: 0,
        max: 5,
        idle: 10000
    },
    define: {
        timestamps: false
    }
})
class Product extends Model {}
Product.init({
    ProdId: { type: DataTypes.INTEGER, primaryKey: true },
    ProdName: { type: DataTypes.STRING, allowNull: false }
}, { sequelize, modelName: "Product" });
const products = [
    { ProdId: 101, ProdName: 'P1' },
    { ProdId: 102, ProdName: 'P2' }
];




instance.get('/api/products', (req, resp) => {
    sequelize.sync({ force: false })
        .then(() => Product.bulkCreate(products, { validate: true }))
        .then((result) => {
            resp.json({ statusCode: 200, data: result });
            resp.end();
        }).error((error) => {
            resp.send({ statusCode: 500, data: `Error Occured ${error}` });
            resp.end();
        });
});

instance.post('/api/products', (req, resp) => {
    const product = {
        ProdId: req.body.ProdId,
        ProdName: req.body.ProdName
    };
    products.push(product);
    resp.json({ statusCode: 200, data: products });
    resp.end();
});



instance.listen('9088', () => {
    console.log('Server started on port 9088');
});